package com.example.abricateengineering;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AbricateengineeringApplication {

	public static void main(String[] args) {
		SpringApplication.run(AbricateengineeringApplication.class, args);
	}

}
